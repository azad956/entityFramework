﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntityFrameWorkEample.DataBaseContext;
using EntityFrameWorkEample.Models;

namespace EntityFrameWorkEample
{
    class Program
    {
        static void Main(string[] args)
        {
            //Employee employee = new Employee()
            //{
            //    Name = "tanmoy",
            //    Address = "Dhaka",
            //    Salary = 20000
            //};
            //EmployeeDbContext db = new EmployeeDbContext();
            //db.Employees.Add(employee);

            // update db opeations

            EmployeeDbContext db = new EmployeeDbContext();
            Employee employee = db.Employees.FirstOrDefault(c => c.Id == 3);
            if (employee != null)
            {
                employee.Name = "apu";
                employee.Address = "alamdanga";
                employee.Salary = 30000;
            }

            int rowaffected = db.SaveChanges();
            if (rowaffected > 0)
            {
                Console.WriteLine("Saved successfully");
            }

            Console.ReadKey();
        }
    }
}
